# Shah Pharmacy Android

Mobile-first pharmacy management app.

## Secure local database
- Uses Android SQLite for persistent records.
- Database values are encrypted at rest with AES-GCM using an Android Keystore key.
- Pharmacy records and staff accounts are no longer stored in browser localStorage.
- Existing version-1 plaintext database records are migrated to encrypted storage on first access.
- JSON export/restore remains available; exported files are not encrypted, so keep backups private.

## Important
This protects records stored on the Android device. It is not a cloud database or automatic multi-device sync. For multi-device access, automatic backup, or remote recovery, connect the app to a secure backend such as Supabase/Firebase with authenticated access and server-side security rules.
