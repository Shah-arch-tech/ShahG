# Shah Pharmacy — Cloud Database Setup

This version uses **Supabase Auth + Postgres + Row Level Security (RLS)**.

## 1. Create Supabase project
Create a project at https://supabase.com.

## 2. Create database tables
Open **SQL Editor** and run `supabase_schema.sql` from this project.

## 3. Configure the Android app
Open:
`app/src/main/assets/config.js`

Set:
- `url` = your Supabase Project URL
- `anonKey` = your Supabase publishable/anon key

**Do not use the `service_role` key.**

## 4. First admin
Use **Create Account** in the app. Confirm the email if email confirmation is enabled.
Then in Supabase SQL Editor run:

`update public.profiles set role='admin' where username='YOUR_USERNAME';`

## 5. Staff
Create staff users in Supabase Authentication. Their profile is automatically created as `staff` by the trigger. Admin can manage roles in the Supabase dashboard.

## Data model
The app keeps the existing purchase/sale/expense structure inside one cloud JSON document per authenticated user. RLS restricts that document to its owner. The first cloud login also migrates existing local Android records when the cloud record is empty.
